
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/quizJSPServlet")
public class quizJSPServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session= request.getSession();
        session.setAttribute("age",request.getParameter("age").trim().toString());
        int currentQuestionNo = Integer.parseInt(session.getAttribute("currentQuestionNo").toString());
        String currentQuestion= Quiz.questions[currentQuestionNo];
        session.setAttribute("currentQuestion",currentQuestion);
        int ans=  Integer.parseInt(request.getParameter("next").trim().toString());
        int scores = Integer.parseInt(request.getParameter("scores").toString());
        int count = Integer.parseInt(session.getAttribute("count").toString());


        if ((Quiz.computeScore(currentQuestionNo, ans, count) == 0) && (count <=3)) {
            session.setAttribute("count", ++count);
            RequestDispatcher rd = request.getRequestDispatcher("numberQuizJSP.jsp");
            rd.forward(request, response);
        }
        else if (((Quiz.computeScore(currentQuestionNo, ans, count) == 0)) &(count >=3)) {
            session.setAttribute("count", ++count);
            request.getRequestDispatcher("quizJSPPost.jsp").forward(request, response);
        }
        else {
            scores+= Quiz.computeScore(currentQuestionNo, ans, count);
            session.setAttribute("currentQuestionNo", ++currentQuestionNo);
            currentQuestion = Quiz.questions[currentQuestionNo];
            request.setAttribute("currentQuestion", currentQuestion);
            count = 0;
            session.setAttribute("scores",scores);

            if (currentQuestionNo < Quiz.getQuestions().length) {
                RequestDispatcher rd = request.getRequestDispatcher("numberQuizJSP.jsp");
                rd.forward(request, response);
            }
            else {

                RequestDispatcher rd = request.getRequestDispatcher("quizJSPResult.jsp");
                String  grade="";

                int scr= Integer.parseInt(session.getAttribute("scores").toString());
                if ( scr> 45 & scr<55){
                    grade= "A";
                }
                else  if ( scr> 35 & scr<44){
                    grade= "B";
                }
                else if (scr> 25 & scr<34){
                    grade= "C";
                }
                else  grade= "NC";

                request.setAttribute("grade" ,grade);
                rd.forward(request, response);
            }
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int scores= 0;
        HttpSession session = request.getSession();
        int currentQuestionNo=0;
        int count=1;
        session.setAttribute("count", count);
        Quiz q= new Quiz();
        session.setAttribute("age",request.getParameter("age").trim().toString());
        session.setAttribute("scores",scores);
        session.setAttribute("currentQuestionNo", currentQuestionNo);
        String currentQuestion= Quiz.questions[currentQuestionNo];
        session.setAttribute("currentQuestion",currentQuestion);
        RequestDispatcher rd = request.getRequestDispatcher("numberQuizJSP.jsp");
        rd.forward(request, response);

    }

}
