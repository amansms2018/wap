public   class Quiz {

    public Quiz() {
    }

    public static String[] getQuestions() {
        return questions;
    }



    public static String[] questions =
            {"3, 1, 4, 1,5",
                    "1, 1, 2, 3,5",
                    "1,4,9,16,25",
                    "2, 3, 5,7,11",
                    "1,2,4,8,16"};

    public static int[] answers = {9, 8, 36, 13, 32};
    private int [] count={0, 1,2};

    public static int computeScore(int queNum, int ans, int count) {
        switch (queNum ) {

            case 0:
                if (answers[queNum] == ans) return computeWeight(count);
            case 1:
                if (answers[queNum] == ans) return computeWeight(count);
                case2:
                if (answers[queNum] == ans) return computeWeight(count);
                break;
            case 2:
                if (answers[queNum] == ans) return computeWeight(count);
                break;
            case 3:
                if (answers[queNum] == ans) return computeWeight(count);
                break;
            case 4:
                if (answers[queNum] == ans) return computeWeight(count);
                break;
        }

        return 0;

    }
    public static int computeWeight( int count ){
        switch ( count){
            case 1:
                return  10;
            case 2:
                return 5;
            case 3: return 2;
        }return 0;
    }
    public static void setQuestions(String[] questions) {
        Quiz.questions = questions;
    }
}
