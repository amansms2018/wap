$(document).ready(function () {
    $("#lookup").click(function(){
        var word = $("#word").val();
        $.ajax({
            url: "dictServlet",
            data: {word:word},
            type: "POST",
            dataType: "JSON",
            success: function (data2) {
                // alert(data2[0].definition);
                var myData="\n";
                   for(i=0;i<data2.length;i++){
                   var p=data2[i];
                       myData+="<tr><td> "+ (i+1) +"(" +p.wordtype +")::  "+p.definition+"</td></tr>";
                      }
                    $('#content').html(myData);
                    },
                  error: function (data2) {
                alert("Failed" + data2.toString());
            }
        });
    });
});
