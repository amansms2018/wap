//import com.google.gson.Gson;
//import com.google.gson.JsonArray;
//import com.google.gson.JsonElement;
//import com.google.gson.reflect.TypeToken;
import com.google.gson.JsonArray;
import org.json.JSONArray;
import org.json.JSONArray;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "dictServlet")
public class dictServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static Connection connection = null;
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	private static final String DB_URL = "jdbc:mysql://localhost:3306/entries?" +
			"autoReconnect=true&useSSL=false" + "&useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	private static final String USERNAME = "root";
	private static final String PASSWORD = "12qwaszx";

	//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		List<Entry> entries=new ArrayList<Entry>();
//		entries = FetchData.getAllWords();
//
//		Gson gson = new Gson();
//		JsonElement element = gson.toJsonTree(entries, new TypeToken<List<Entry>>(){}.getType());
//		JsonArray jsonArray = element.getAsJsonArray();
//
//		response.setContentType("application/json");
//
//		response.getWriter().print(jsonArray);
//
//        //////////
//		 FetchData fd= new FetchData();
//         entries= new ArrayList<>();
//         entries= fd.getAllWords();
//
//       String xx= fd.getAllWords().get(0).toString();
//	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		String keyword = request.getParameter("word");
		JsonArray jsonArray= FetchData.getJSOnArray_Atomatically(keyword);
		response.getWriter().print(jsonArray);
	}
}


