public class Entry {
	private String word;

	public Entry(String word, String wordtype, String definition) {
		this.word = word;
		this.wordtype = wordtype;
		this.definition = definition;
	}

	public Entry(){
	}

	private String wordtype;

	public void setWord(String word) {
		this.word = word;
	}

	public void setWordtype(String wordtype) {
		this.wordtype = wordtype;
	}

	public void setDefinition(String definition) {
		this.definition = definition;
	}

	public String getWord() {
		return word;
	}

	public String getWordtype() {
		return wordtype;
	}

	public String getDefinition() {
		return definition;
	}

	private String definition;

	@Override
	public String toString() {
		return "{" +"word:" + word + ", wordtype:" + wordtype + ", definition:" + definition + "}";
	}
}

