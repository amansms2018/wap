import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.google.gson.JsonArray;
import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import  java.sql.PreparedStatement;


public class FetchData {
    private static Connection connection = null;
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private static final String DB_URL ="jdbc:mysql://localhost:3306/entries?useUnicode=true" +
            "&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "12qwaszx";
    Statement stmt= null;
    public static Connection getConnection() {
        if (connection != null)
            return connection;
        else {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                System.out.println(e.toString());
            }
            return connection;
        }

    }
    
    public static List<Entry> getAllWords(String keyWord) {

        List<Entry> listOfsimilarWord = new ArrayList<Entry>();
        try {
           connection =  getConnection();//DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement statement = connection.createStatement();
            String query = "SELECT * FROM entries WHERE word = ?";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString   (1, keyWord);
            ResultSet rs =preparedStmt.executeQuery();

            while(rs.next()) {
            	Entry wList=new Entry();
//            	wList.setWord(rs.getString("word"));
            	wList.setWordtype(rs.getString("wordtype"));
                wList.setDefinition(rs.getString("definition"));
                listOfsimilarWord.add(wList);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return listOfsimilarWord;
    }

//    public static JSONArray  getJSonArray(String  keyword){
//        List<Entry> entries=new ArrayList<Entry>();
//        entries = FetchData.getAllWords(keyword);
//        JSONArray jsonArray = new JSONArray();
//        System.out.println("\n\n");
//        for (Entry ee:entries){
//            jsonArray.put(ee.toString()+ "\n");
//        }
//        for(int xx=0; xx<jsonArray.length(); xx++)
//            System.out.println(jsonArray.get(xx));
//        return jsonArray;
//    }
 public  static JsonArray getJSOnArray_Atomatically( String keyword){
        List<Entry> entries=new ArrayList<Entry>();
		entries = FetchData.getAllWords(keyword);
		Gson gson = new Gson();
		JsonElement element = gson.toJsonTree(entries, new TypeToken<List<Entry>>(){}.getType());
		JsonArray jsonArray = element.getAsJsonArray();
		for ( int xx=0; xx<jsonArray.size(); xx++) {
         System.out.println(jsonArray.get(xx).toString());
        }
return jsonArray;
    }
    public  static void main(String [] args){
//        JSONArray jr1 = new JSONArray();
//         jr1= getJSonArray( "king");

        JsonArray jr1 = new JsonArray();
         jr1= getJSOnArray_Atomatically( "king");
    }

}